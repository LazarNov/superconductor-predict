import FRSP

FRSP.FourierSt()